import readline from 'readline';
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
function calcularSalarioTotal(salarioBase, horasExtras, valorHora) {
 const pagoHorasExtras = horasExtras * (valorHora * 1.5);
 return salarioBase + pagoHorasExtras;
}

rl.question('Ingrese su salario base: ', (salario) => {
   
 rl.question('Ingrese el número de horas extras trabajadas: ', (horas) => {
 
        rl.question('Ingrese el valor de una hora normal: ', (valorHora) => {
 
            const total = calcularSalarioTotal(parseFloat(salario), parseFloat(horas), parseFloat(valorHora)); console.log('Su salario total es:', total.toFixed(2));
 
     rl.close();
 });
 });
});