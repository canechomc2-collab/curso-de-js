import readline from 'readline';
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

function sumaTotal(pre1, pre2, pre3) {
 return pre1 + pre2 + pre3;
}
 rl.question('Ingrese el precio del primer producto: ', (pre1) => {

   rl.question('Ingrese el precio del segundo producto: ', (pre2) => {

      rl.question('Ingrese el precio del tercer producto: ', (pre3) => {
  const total = sumaTotal(parseFloat(pre1), parseFloat(pre2), parseFloat(pre3));
 console.log('La suma total es:', total.toFixed(2));

       rl.close();
      });


     });
});