import readline from 'readline';
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
function ordenarCadena(cadena) {
 return cadena.split('').sort().join('');

}
rl.question('Ingrese una palabra o frase: ', (texto) => {
    
 console.log('Texto ordenado alfabéticamente:', ordenarCadena(texto));
 rl.close();
});